Race Points Manager (RPM)

By: Chris Squier (online: tonysq)

Version: 01.10.00 (read version.txt for changes)

Description: A database program to help league administrators manage driver's
points, penalties and bonuses.

Homepage: http://www.bumpnrub.com

E-mail: Please report any bugs or suggestions to: tonysq@yahoo.com

License
-------
This program is freeware as long as you use it for non-commercial
use. The program may not be distributed on a media (such as a CD-Rom or a 
diskette) for which money is charged OR on a media distributed with for 
example a magazine for which money is charged without the author's permission.


DISCLAIMER
----------
This software is provided "as is" without warranty of any kind, either 
expressed or implied. Use it at your own risk.

THIS IS NOT A SIERRA/PAPYRUS PRODUCT
